#!/usr/bin/env python
from setuptools import setup, find_packages

PROJECT = 'mpsclient'

# Change docs/sphinx/conf.py too!
VERSION = '5.0.1'

try:
    long_description = open('README.txt', 'rt').read()
except IOError:
    long_description = ''

setup(
    name=PROJECT,
    version=VERSION,

    description='mps client package for PlatforMax 5.0.1',
    long_description=long_description,

    author='Gavin Li',
    author_email='gavin_li@amaxgs.com',

    classifiers=['Development Status :: 3 - Alpha',
                 'License :: OSI Approved :: Apache Software License',
                 'Programming Language :: Python',
                 'Programming Language :: Python :: 3',
                 'Programming Language :: Python :: 3.6',
                 'Intended Audience :: Developers',
                 'Environment :: Console',
                 ],

    platforms=['Any'],

    scripts=[],

    provides=[],
    install_requires=[''],

    namespace_packages=[],
    packages=find_packages(),
    include_package_data=True,
    package_data={
        '': ['*.json']
    },

    zip_safe=False,
)
