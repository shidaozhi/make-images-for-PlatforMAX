import signal
import os
import psutil
import multiprocessing as mp
import time
import socket
import json
import urllib3
import subprocess

def terminate_client(signum, frame):
    pid = os.getpid()
    terminate(pid)
    #sys.exit(0)

def terminate(pid):
    process = psutil.Process(pid)
    children = process.children()
    for child in children:
        terminate(child.pid)
    doTerminate(pid)

def doTerminate(pid):
    mpsEnv = os.getenv("MPS", "true")
    if mpsEnv.upper() == "TRUE":
        command = f"cat /proc/1/environ | tr '\\0' '\\n' | grep aimax.container.hostname | awk -F \"=\" '{{print $2}}'"
        popen = subprocess.Popen(command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        ret = popen.wait()
        if ret == 0:
            host = popen.stdout.readline().decode("UTF-8").strip()
            terminateViaMTS(host, pid)
            os.kill(pid, signal.SIGTERM)
        else:
            print("MTS host hasn't been set, terminate process {pid} directly")
            os.kill(pid, signal.SIGTERM)
    else:
        os.kill(pid, signal.SIGTERM)
    print(f"Process {pid} terminated")

def terminateViaMTS(host, pid):
    http = urllib3.PoolManager()
    hostname = socket.gethostname()
    url = f"http://{host}:1380/container/{hostname}/pid/{pid}"
    r = http.request('GET', url)
    if r.status == 200:
        result = json.loads(r.data.decode())
        if result["success"]:
            hostPID = result["pid"]
            #查看mps中是否存在主机进程
            command = f"echo 'ps' | nvidia-cuda-mps-control | awk '{{print $1,$3}}' | grep {hostPID}"
            popen = subprocess.Popen(command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            ret = popen.wait()
            if ret == 0:
                items = popen.stdout.readline().decode("UTF-8")
                if len(items) >= 2:
                    servPID = items[1]
                    command = f"echo 'terminate_client {servPID} {hostPID}' | nvidia-cuda-mps-control"
                    popen = subprocess.Popen(command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    ret = popen.wait()
                    if ret == 0:
                        print(f"Process {pid} has been terminated via mps control successfully")
                    else:
                        print(f"Failed to ternimate process {pid} via mps control")
                else:
                    print(f"Server pid format is invalid")
            else:
                print(f"Failed to get mps server pid")
        else:
            print(f"Failed to get host pid of process {pid}")
    else:
        print(f"Failed to load nodes from {url}, status={r.status}")

def handle():
    signal.signal(signal.SIGINT, terminate_client)

def test(num, msg):
    print("---子进程的pid=%d, ppid=%d, num=%d, msg=%s" % (os.getpid(), os.getppid(), num, msg))
    while True:
        print(time.strftime('%Y:%m:%d %H:%M:%S', time.localtime(time.time())))
        time.sleep(1)

if __name__ == '__main__':
    pass
    """ handle()
    p1 = mp.Process(target=test, args=(1, "Process1"))
    p2 = mp.Process(target=test, args=(2, "Process2"))
    p1.start()
    p2.start() """
    